Haunted Heights

Project version 1.3

Player hits nails on screen to advance their score. The players must avoid getting the spawn order wrong as the ghost speeds up with every mistake

Controls - Mouse and Keyboard, Mobile touch screen.
Haunted Heights How to play- The player taps on the nails spawning on the screen, in the order they are presented to score points. They must keep scoring in order to stay away from the ghost which speeds up at their mistakes.


Release Notes for Version Feature B - a section with multiple subsections that list the update status of features and bugs in the latest version. Section include:
Ghost feature- The ghost brings in a lose condition and also functions with the tapping mechanic to provide a threat to the player. 
Feature A was changed as it now requires the nails to be hit in the order they spawn in.
Bugs that need fixing- The ghost speeds up way too much, nails can spawn before the player hits a collision box, and there is a chance the player can fall off the roof.

Release Notes for Version Feature C - 
Power up feature added- Power ups slow down ghost, Double the points scored, and auto build tiles. Power ups can be found on the path to the end.
New house was set up for the player to build
Tiles have been reworked to fill in gaps in the path.
Feature B adds a number tracker to show distance between ghost and player (Progress bar to be added in future build)
Bugs that need fixing- The ghost speed up is still rampant, ghost can get slowed down way too much by power up, nails can spawn before the player hits a collision box, and possibility for camera to get knocked off the track.